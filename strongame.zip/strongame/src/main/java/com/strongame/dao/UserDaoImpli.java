package com.strongame.dao;
/*
 * @author gunapal.p
 */
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.strongame.dto.RegisterUserDto;
import com.strongame.entity.RegisterUser;

@Repository
public class UserDaoImpli implements UserDao {

	@PersistenceContext
	EntityManager manager;

	@Override
	@Transactional
	public RegisterUserDto registerUser(RegisterUserDto register) {

		RegisterUser newRegister = new RegisterUser();
		RegisterUserDto dto = new RegisterUserDto();
		BeanUtils.copyProperties(register, newRegister);
		manager.persist(newRegister);
		BeanUtils.copyProperties(newRegister, dto);
		return dto;

	}

}
