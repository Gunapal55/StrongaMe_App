package com.strongame.dao;
import com.strongame.dto.RegisterUserDto;

public interface UserDao {

	public RegisterUserDto registerUser(RegisterUserDto register);

//	public LoginUserDto loginUser(LoginUserDto login);
//	
//	public UserDetailsDto getAllInfo(UserDetialsDto details);
//	
//	public UserDetialsDto updateProfile(UserDetialsDto profileInfo);
//	
//	public UserDetialsDto changePassword(UserDetialsDto plan);
//	
//	public UserDetialsDto buyProduct(UserDetialsDto plan);
//	
//	public UserDetialsDto trackSteps(UserDetials steps);
//	
	
	
}
