package com.strongame.controller;
/*
 * @author gunapal.p
 */

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.strongame.dto.RegisterUserDto;
import com.strongame.dto.ResponseDto;
import com.strongame.service.UserService;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "*")
public class UserController {

	@Autowired
	private UserService service;

	@PostMapping()
	public ResponseDto addProduct(@RequestBody RegisterUserDto data) {
		ResponseDto dto = new ResponseDto();
		dto.setData(service.registerUser(data));
		return dto;
	}

}
