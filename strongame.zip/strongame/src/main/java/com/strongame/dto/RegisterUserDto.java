package com.strongame.dto;
/*
 * @author gunapal.p
 */
import java.io.Serializable;
import java.sql.Date;

import lombok.Data;

@Data
public class RegisterUserDto implements Serializable {

	private static final long serialVersionUID = 8222627122512465779L;

	private int registerId;

	private String name;

	private Date userDob;

	private String userEmail;

	private String password;

	private String confirmPassword;

	private long userPhoneNumber;

	private String referalCode;

}
