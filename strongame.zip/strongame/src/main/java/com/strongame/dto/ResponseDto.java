package com.strongame.dto;
/*
 * @author gunapal.p
 */
import java.io.Serializable;

import lombok.Data;

@SuppressWarnings("serial")
@Data
public class ResponseDto implements Serializable{

		private boolean error;
		private Object data;
	
}
