package com.strongame.dto;
/*
 * @author gunapal.p
 */
public class UserLoginDto {

	
}
