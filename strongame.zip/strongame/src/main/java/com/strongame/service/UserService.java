package com.strongame.service;
import com.strongame.dto.RegisterUserDto;

public interface UserService {

	public RegisterUserDto registerUser(RegisterUserDto register);
}
