package com.strongame.service;
/*
 * @author gunapal.p
 */

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.strongame.dao.UserDao;
import com.strongame.dto.RegisterUserDto;
import com.strongame.exception.UserException;

@Service
public class UserServicesImpli implements UserService {

	@Autowired
	private UserDao dao;

	@Override
	public RegisterUserDto registerUser(RegisterUserDto register) {

		if (register != null) {
			RegisterUserDto dto = null;
			dto = dao.registerUser(register);
			return dto;

		} else {
			throw new UserException("Failed to register new user: user data should not be empty!");

		}

	}

}