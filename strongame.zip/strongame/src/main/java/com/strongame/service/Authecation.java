//package com.strongame.service;
//
//public class Authecation {
//	
//	String pwd="abcd123";
//	
//	char[] chars = pwd.toCharArray();
//	
//	for(char c : chars) {
//		c +=7;
//		System.out.println(c);
//	}
//	
//}
